#include<stdio.h>
void main (void){

char name[20],DOB[20],Mobile[20];

printf("Enter your name=\n");
scanf("%s",&name);

printf("Enter your date of birth=\n");
scanf("%s",&DOB);

printf("Enter your mobile number=\n");
scanf("%s",&Mobile);

printf("Name   : %s\n",name);
printf("DOB    : %s\n",DOB);
printf("Mobile : %s\n",Mobile);
	
}
