#include<stdio.h>
void main (void){

char ch1[20],ch2[20],ch3[20];

printf("Enter the first letter=");
scanf("%s",&ch1);

printf("\nEnter the second letter=");
scanf("%s",&ch2);

printf("\nEnter the third letter=");
scanf("%s",&ch3);

printf("'%s','%s','%s'",ch3,ch2,ch1);

}
