#include<stdio.h>
#include<conio.h>
void main (void){

int var1,var2,sum;
var1=var2=sum=0;

printf("Enter the first integer\n");
scanf("%d", &var1);

printf("Enter the second integer\n");
scanf("%d", &var2);

sum=var1+var2;

printf("Sum of the above two integers is= %d\n",sum);

}
